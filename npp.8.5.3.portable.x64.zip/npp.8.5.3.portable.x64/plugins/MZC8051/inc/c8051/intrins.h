#ifndef __INTRINS_H__
#define __INTRINS_H__

#pragma SAVE

#if defined (__CX2__)
#pragma FUNCTIONS(STATIC)
/* intrinsic functions are reentrant, but need static attribute */
#endif

inline void          _nop_     (void)
{
	_inline_asm_("nop;\n");
}
inline bit           _testbit_ (bit)
{
	
}
inline unsigned char _cror_    (unsigned char a, unsigned char b)
{
	return a>><b;
}
inline unsigned int  _iror_    (unsigned int a,  unsigned char b)
{
	return a>><b;
}
inline unsigned long _lror_    (unsigned long a, unsigned char b)
{
	return a>><b;
}
inline unsigned char _crol_    (unsigned char a, unsigned char b)
{
	return a><<b;

}
inline unsigned int  _irol_    (unsigned int a,  unsigned char b)
{
	return a><<b;

}
inline unsigned long _lrol_    (unsigned long a, unsigned char b)
{
	return a><<b;
}
extern unsigned char _chkfloat_(float);
#if defined (__CX2__)
extern int           abs       (int);
extern void          _illop_   (void);
#endif
#if !defined (__CX2__)
extern void          _push_    (unsigned char _sfr);
extern void          _pop_     (unsigned char _sfr);
#endif

#pragma RESTORE

extern inline void _inline_asm_(const char * asm_str);


#endif

