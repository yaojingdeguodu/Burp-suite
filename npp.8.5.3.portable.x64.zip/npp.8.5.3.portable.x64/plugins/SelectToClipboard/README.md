# SelectToClipboard
[![Build status](https://ci.appveyor.com/api/projects/status/github/kubadee/SelectToClipboard?svg=true)](https://github.com/KubaDee/SelectToClipboard)
### by Jakub Dvorak


N++ plugin - auto copy selected text to clipboard. You can automatically copy selected text like in PuTTY (or similar) terminal application. This plugin comes with absolutely no warranty.  

Latest Updates:
----  
### v1.0.3
Fix crash on N++ version 8.3+

### v1.0.2
Code tidying

### v1.0.1
Fixed copying text to clipboard when switching between tabs

### v1.0
Initial release
