#TODO
# - Disable buttons when saving state/restoring state/export
# - Add full headers in addition to cookies